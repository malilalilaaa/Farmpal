import 'package:flutter/material.dart';

Color button = const Color.fromARGB(255, 117, 210, 115);
Color irrigationbutton = const Color.fromARGB(255, 49, 160, 155);
Color text1 = Colors.white;
Color text2 = const Color.fromARGB(255, 34, 22, 22);
Color droughtbutton = const Color.fromARGB(255, 246, 167, 130);
Color agriadviser = const Color.fromARGB(255, 199, 138, 229);
Color otpconatainer = const Color.fromARGB(255, 217, 217, 217);
