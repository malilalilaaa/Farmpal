import 'dart:convert';

import 'package:entry/drought/models/weather_model.dart';
import 'package:http/http.dart' as http;

class WeatherServices {
  fetchWeather() async {
    final response = await http.get(
      Uri.parse(
          "https://api.openweathermap.org/data/2.5/weather?lat=22.3496&lon=91.8263&appid=OpenWeather_API_KEY"),
    );
    try {
      if (response.statusCode == 200) {
        var json = jsonDecode(response.body);
        return WeatherData.fromJson(json);
      } else {
        throw Exception('Failed to load Weather Data');
      }
    } catch (e) {}
  }
}
