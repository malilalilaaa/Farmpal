const OpenWeather_API_KEY = "4914a82e42703248a746f5fd89998f9a";
