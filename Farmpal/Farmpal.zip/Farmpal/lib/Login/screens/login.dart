import 'package:entry/Login/screens/location.dart';
import 'package:entry/Login/screens/register.dart';
import 'package:entry/dashboard_Profile/dashboard.dart';
import 'package:entry/dashboard_Profile/features.dart';
import 'package:entry/dashboard_Profile/drawer_screen.dart';
import 'package:entry/util/pallete.dart';
import 'package:flutter/material.dart';

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  bool isClicked = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          const Center(
            child: Image(
              image: AssetImage('assets/images/login.png'),
              fit: BoxFit.cover,
              width: double.infinity,
              height: double.infinity,
            ),
          ),
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Image.asset(
                  'assets/images/farmer.png',
                  width: 181,
                  height: 170,
                ),
                const SizedBox(height: 40),
                const Text(
                  'Welcome Back!',
                  style: TextStyle(
                    fontFamily: 'Cera Pro',
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
                const SizedBox(height: 50),
                Center(child: textField("Phone Number")),
                const SizedBox(
                  height: 25,
                ),
                Center(child: textField("Password")),
                const SizedBox(
                  height: 10,
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 25, left: 5),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 80,
                        child: Container(
                          height: 20,
                          width: 20,
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.white70,
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.5),
                                  spreadRadius: 2,
                                  blurRadius: 5,
                                  offset: const Offset(0, 3),
                                )
                              ]),
                          child: GestureDetector(
                            onTap: () {
                              setState(
                                () {
                                  isClicked = !isClicked;
                                },
                              );
                            },
                            child: Center(
                              child: Container(
                                height: 15,
                                width: 15,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: isClicked
                                      ? Colors.white
                                      : const Color.fromARGB(255, 34, 113, 38),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(
                        width: 1,
                      ),
                      const Text(
                        "Remember Me",
                        style: TextStyle(
                          fontFamily: 'Cera Pro',
                          fontSize: 17,
                          color: Color.fromARGB(255, 144, 196, 146),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(
                  height: 30,
                ),
                const Text(
                  "Forget Password",
                  style: TextStyle(
                    fontFamily: 'Cera Pro',
                    fontSize: 17,
                    color: Color.fromARGB(255, 93, 167, 95),
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(
                  height: 30,
                ),
                GestureDetector(
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) => const Register(),
                      ),
                    );
                  },
                  child: RichText(
                    text: const TextSpan(
                      children: [
                        TextSpan(
                          text: "Don't have an account? ",
                          style: TextStyle(
                            fontFamily: 'Cera Pro',
                            fontSize: 17,
                            color: Pallete.subheading,
                          ),
                        ),
                        TextSpan(
                          text: "SIGN UP!",
                          style: TextStyle(
                            fontFamily: 'Cera Pro',
                            fontSize: 17,
                            color: Pallete.heading,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                GestureDetector(
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) => const Dashboard(),
                      ),
                    );
                  },
                  child: Container(
                    height: 60,
                    width: 250,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(50),
                      gradient: const LinearGradient(
                        colors: [
                          Color.fromARGB(255, 152, 238, 179),
                          Color.fromARGB(255, 22, 165, 139),
                        ],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.5),
                          spreadRadius: 2,
                          blurRadius: 5,
                          offset: const Offset(0, 3),
                        ),
                      ],
                    ),
                    child: const Center(
                      child: Text(
                        " Login",
                        style: TextStyle(
                          fontFamily: 'Cera Pro',
                          fontSize: 30,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget textField(hint) {
    return SizedBox(
      width: 350,
      child: Material(
        color: Colors.white,
        elevation: 7,
        borderRadius: BorderRadius.circular(30),
        child: Padding(
          padding: const EdgeInsets.symmetric(
            vertical: 10.0,
            horizontal: 30.0,
          ),
          child: TextFormField(
            decoration: InputDecoration(
              hintText: hint,
              helperStyle: const TextStyle(
                color: Colors.black38,
                fontFamily: 'Cera Pro',
                fontWeight: FontWeight.bold,
              ),
              border: InputBorder.none,
            ),
          ),
        ),
      ),
    );
  }
}
