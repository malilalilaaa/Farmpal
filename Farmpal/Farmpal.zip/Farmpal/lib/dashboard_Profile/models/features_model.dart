class Feature {
  final int id;
  final String name;
  final String imagePath;

  Feature({
    required this.id,
    required this.name,
    required this.imagePath,
  });
}

// ignore: camel_case_types
class image_video {
  final int id;
  final String name;
  final String imagePath;

  image_video({
    required this.id,
    required this.name,
    required this.imagePath,
  });
}
