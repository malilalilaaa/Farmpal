import 'dart:ui'; // Ensure you have this for ImageFilter
import 'package:entry/util/pallete.dart';
import 'package:flutter/material.dart';

class DrawerScreen extends StatefulWidget {
  const DrawerScreen({super.key});

  @override
  _DrawerScreenState createState() => _DrawerScreenState();
}

class _DrawerScreenState extends State<DrawerScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 1.2 * kToolbarHeight, 0, 15),
            child: Stack(
              children: [
                // Circle UI Elements
                Align(
                  alignment: const AlignmentDirectional(9, -0.3),
                  child: Container(
                    height: 300,
                    width: 300,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      color: Pallete.floodui1,
                    ),
                  ),
                ),
                Align(
                  alignment: const AlignmentDirectional(-9, -0.3),
                  child: Container(
                    height: 300,
                    width: 300,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      color: Pallete.floodui1,
                    ),
                  ),
                ),
                Align(
                  alignment: const AlignmentDirectional(0, -1.2),
                  child: Container(
                    height: 300,
                    width: 600,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      color: Pallete.floodui2,
                    ),
                  ),
                ),
                // Blur effect
                BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 100.0, sigmaY: 100.0),
                  child: Container(
                    decoration: const BoxDecoration(
                      color: Colors.transparent,
                    ),
                  ),
                ),
                Container(
                  child: Padding(
                    padding: EdgeInsets.only(top: 50, left: 40, bottom: 70),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            CircleAvatar(
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(60),
                                child: const Image(
                                  fit: BoxFit.cover,
                                  image: AssetImage(
                                      'assets/images/profile_pic.jpg'),
                                ),
                              ),
                            ),
                            const SizedBox(width: 10),
                            const Text(
                              'Akkas Kadder',
                              style: TextStyle(
                                fontFamily: 'Cera Pro',
                                color: Pallete.heading,
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 30),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            NewRow(
                              text: 'Dark Mode',
                              icon: Icons.dark_mode_outlined,
                              onTap: () {},
                            ),
                            const SizedBox(height: 20),
                            NewRow(
                              text: 'Setting',
                              icon: Icons.error_outline,
                              onTap: () => _onSettingTapped(),
                            ),
                            const SizedBox(height: 20),
                            NewRow(
                              text: 'Profile',
                              icon: Icons.person_2_outlined,
                              onTap: () => _onProfileTapped(),
                            ),
                            const SizedBox(height: 20),
                            NewRow(
                              text: 'Language',
                              icon: Icons.language_outlined,
                              onTap: () => _onLanguageTapped(),
                            ),
                            const SizedBox(height: 20),
                            NewRow(
                              text: 'Log Out',
                              icon: Icons.logout_outlined,
                              onTap: () => _onLogoutTapped(),
                            ),
                            const SizedBox(height: 20),
                          ],
                        )
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _onLogoutTapped() {}

  void _onLanguageTapped() {}

  void _onProfileTapped() {}

  void _onSettingTapped() {}
}

class NewRow extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback onTap;

  const NewRow({
    super.key,
    required this.icon,
    required this.text,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Row(
        children: [
          Icon(
            icon,
            color: Pallete.blackColor,
          ),
          const SizedBox(width: 20),
          Text(
            text,
            style: const TextStyle(
              fontFamily: 'Cera Pro',
              color: Color.fromARGB(255, 2, 30, 21),
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}
