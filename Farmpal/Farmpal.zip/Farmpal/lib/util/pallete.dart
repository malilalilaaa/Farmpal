import 'package:flutter/material.dart';

class Pallete {
  static const Color mainFontColor = Colors.black87;
  // ignore: constant_identifier_names
  static const Color button_heading = Color.fromRGBO(117, 210, 115, 1.0);
  static const Color heading = Color.fromRGBO(10, 95, 9, 1);
  static const Color subheading = Color.fromRGBO(117, 210, 115, 1.0);
//dashboard
  static const Color irrigation = Color.fromRGBO(49, 160, 155, 1.0);
  static const Color drought = Color.fromRGBO(246, 167, 130, 1.0);
  static const Color flood = Color.fromRGBO(199, 138, 229, 1.0);
  static const Color agriadviser = Color.fromRGBO(212, 211, 44, 1.0);
  static const Color disease = Color.fromRGBO(78, 172, 137, 1.0);
  static const Color xorina = Color.fromRGBO(216, 196, 226, 1.0);
  static const Color community = Color.fromRGBO(225, 250, 229, 1.0);
//Xorina
  static const mainfontcolor = Color.fromRGBO(19, 61, 95, 1);
  static const Color firstSuggestionBoxColor = Color.fromRGBO(165, 231, 244, 1);
  static const Color secondSuggestionBoxColor =
      Color.fromRGBO(157, 202, 235, 1);
  static const Color thirdSuggestionBoxColor = Color.fromRGBO(162, 238, 239, 1);
  static const Color assistantCircleColor = Color.fromRGBO(209, 243, 249, 1);
  static const Color borderColor = Color.fromRGBO(200, 200, 200, 1);
  static const Color blackColor = Colors.black;
  static const Color whiteColor = Colors.white;
  static const Color chatdallcolor = Color.fromRGBO(225, 250, 229, 1.0);
//Flood_first
  static const Color floodui1 = Color.fromRGBO(46, 131, 100, 1);
  static const Color floodui2 = Color.fromRGBO(212, 211, 44, 1.0);
  static const Color floodbg = Color.fromRGBO(238, 241, 240, 1);
  static const Color floodcontainer = Color.fromRGBO(117, 210, 115, 1.0);
}
