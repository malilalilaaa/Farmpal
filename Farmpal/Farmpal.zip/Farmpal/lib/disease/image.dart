import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:entry/util/pallete.dart';
import 'package:flutter/services.dart';

// ignore: camel_case_types
class DISEASE_IMAGE extends StatefulWidget {
  const DISEASE_IMAGE({super.key});

  @override
  State<DISEASE_IMAGE> createState() => _Disease_ImageState();
}

// ignore: camel_case_types
class _Disease_ImageState extends State<DISEASE_IMAGE> {
  bool _isTapped = false;
  // ignore: non_constant_identifier_names
  bool _isTapped_second = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Pallete.floodbg,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon:
              const Icon(Icons.arrow_back, color: Color.fromARGB(255, 8, 0, 0)),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        centerTitle: true,
        title: Image.asset(
          'assets/images/flood_logo.png',
          height: 80,
          width: 50,
        ),
        systemOverlayStyle: const SystemUiOverlayStyle(
          statusBarBrightness: Brightness.light,
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(40, 1.2 * kToolbarHeight, 40, 20),
        child: Stack(
          children: [
            // Circle UI Elements
            Align(
              alignment: const AlignmentDirectional(9, -0.3),
              child: Container(
                height: 300,
                width: 300,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: Pallete.floodui1,
                ),
              ),
            ),
            Align(
              alignment: const AlignmentDirectional(-9, -0.3),
              child: Container(
                height: 300,
                width: 300,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: Pallete.floodui1,
                ),
              ),
            ),
            Align(
              alignment: const AlignmentDirectional(0, -1.2),
              child: Container(
                height: 300,
                width: 600,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: Pallete.floodui2,
                ),
              ),
            ),
            // Blur effect
            BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 100.0, sigmaY: 100.0),
              child: Container(
                decoration: const BoxDecoration(
                  color: Colors.transparent,
                ),
              ),
            ),
            Column(
              mainAxisAlignment:
                  MainAxisAlignment.center, // Centers the containers vertically
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Center(
                  child: InkWell(
                    onTap: () {
                      setState(() {
                        _isTapped = !_isTapped;
                      });
                    },
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 300),
                      curve: Curves.easeInOut,
                      padding: const EdgeInsets.all(10),
                      height: _isTapped ? 250 : 200, // Change size when tapped
                      width: _isTapped ? 250 : 200,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.2),
                            spreadRadius: 2,
                            blurRadius: 8,
                            offset: const Offset(4, 4),
                          ),
                        ],
                      ),
                      child: const Image(
                        image: AssetImage("assets/images/upload.png"),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 50,
                ),
                Center(
                  child: InkWell(
                    onTap: () {
                      setState(() {
                        _isTapped_second = !_isTapped_second;
                      });
                    },
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 300),
                      curve: Curves.easeInOut,
                      padding: const EdgeInsets.all(10),
                      height: _isTapped_second
                          ? 250
                          : 200, // Change size when tapped
                      width: _isTapped_second ? 250 : 200,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.2),
                            spreadRadius: 2,
                            blurRadius: 8,
                            offset: const Offset(4, 4),
                          ),
                        ],
                      ),
                      child: const Image(
                        image: AssetImage("assets/images/take.jpg"),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
