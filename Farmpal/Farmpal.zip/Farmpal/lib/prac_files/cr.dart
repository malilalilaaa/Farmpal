// import 'package:flutter/material.dart';
// import 'package:tflite_flutter/tflite_flutter.dart';

// void main() => runApp(CropRecommendationApp());

// class CropRecommendationApp extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       debugShowCheckedModeBanner: false,
//       home: CropForm(),
//     );
//   }
// }

// class CropForm extends StatefulWidget {
//   @override
//   _CropFormState createState() => _CropFormState();
// }

// class _CropFormState extends State<CropForm> {
//   final _formKey = GlobalKey<FormState>();

//   // Text editing controllers for the input fields
//   final TextEditingController _nController = TextEditingController();
//   final TextEditingController _pController = TextEditingController();
//   final TextEditingController _kController = TextEditingController();
//   final TextEditingController _locationController = TextEditingController();
//   final TextEditingController _temperatureController = TextEditingController();
//   final TextEditingController _rainfallController = TextEditingController();
//   final TextEditingController _phController = TextEditingController();

//   List<String> recommendations = [];

//   late Interpreter _interpreter;

//   @override
//   void initState() {
//     super.initState();
//     _loadModel();
//   }

//   // Function to load the TFLite model
//   Future<void> _loadModel() async {
//     try {
//       _interpreter = await Interpreter.fromAsset('model.tflite');
//       print('Model loaded successfully');
//     } catch (e) {
//       print('Error loading model: $e');
//     }
//   }

//   // Function to get recommendations using the TensorFlow Lite model
//   void _getRecommendations() {
//     if (_formKey.currentState!.validate()) {
//       setState(() {
//         // Get the inputs as a float array
//         List<double> input = [
//           double.parse(_nController.text),
//           double.parse(_pController.text),
//           double.parse(_kController.text),
//           0, // Placeholder for location (you may need to encode the location properly)
//           double.parse(_temperatureController.text),
//           double.parse(_rainfallController.text),
//           double.parse(_phController.text),
//         ];

//         // Prepare output tensor (assuming 22 crops for prediction, adjust as per your model)
//         var output = List.filled(1 * 22, 0.0)
//             .reshape([1, 22]); // Change shape to match your model

//         // Run the model
//         _interpreter.run(input, output);

//         // Convert tensor buffer to list
//         List<double> outputList = output[0];
//         List<int> topRecommendations = _getTopNCrops(outputList, 4);

//         // Convert indices to crop names (add more names based on your model's output classes)
//         List<String> cropNames = [
//           'Wheat',
//           'Rice',
//           'Maize',
//           'Soybean',
//           'Cotton',
//           'Barley',
//           'Oats'
//         ];
//         recommendations =
//             topRecommendations.map((index) => cropNames[index]).toList();
//       });
//     }
//   }

//   // Function to get top N crop indices from output probabilities
//   List<int> _getTopNCrops(List<double> probabilities, int n) {
//     List<int> indices = List.generate(probabilities.length, (index) => index);
//     indices.sort((a, b) => probabilities[b].compareTo(probabilities[a]));
//     return indices.take(n).toList();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Crop Recommendation'),
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Form(
//           key: _formKey,
//           child: Column(
//             children: [
//               _buildTextField(_nController, 'Nitrogen (N)', 'Enter N value'),
//               _buildTextField(_pController, 'Phosphorus (P)', 'Enter P value'),
//               _buildTextField(_kController, 'Potassium (K)', 'Enter K value'),
//               _buildTextField(
//                   _locationController, 'Location', 'Enter location'),
//               _buildTextField(_temperatureController, 'Temperature (°C)',
//                   'Enter temperature'),
//               _buildTextField(
//                   _rainfallController, 'Rainfall (mm)', 'Enter rainfall level'),
//               _buildTextField(_phController, 'Soil pH', 'Enter soil pH'),

//               SizedBox(height: 20),

//               ElevatedButton(
//                 onPressed: _getRecommendations,
//                 child: Text('Get Recommendations'),
//               ),

//               SizedBox(height: 20),

//               // Display the crop recommendations
//               recommendations.isNotEmpty
//                   ? Column(
//                       children:
//                           recommendations.map((crop) => Text(crop)).toList(),
//                     )
//                   : Container(),
//             ],
//           ),
//         ),
//       ),
//     );
//   }

//   // Helper function to build the input text fields
//   Widget _buildTextField(
//       TextEditingController controller, String label, String hint) {
//     return Padding(
//       padding: const EdgeInsets.symmetric(vertical: 8.0),
//       child: TextFormField(
//         controller: controller,
//         keyboardType: TextInputType.numberWithOptions(decimal: true),
//         decoration: InputDecoration(
//           labelText: label,
//           hintText: hint,
//           border: OutlineInputBorder(),
//         ),
//         validator: (value) {
//           if (value == null || value.isEmpty) {
//             return 'Please enter $label';
//           }
//           return null;
//         },
//       ),
//     );
//   }

//   @override
//   void dispose() {
//     // Dispose the controllers when the widget is disposed
//     _nController.dispose();
//     _pController.dispose();
//     _kController.dispose();
//     _locationController.dispose();
//     _temperatureController.dispose();
//     _rainfallController.dispose();
//     _phController.dispose();
//     _interpreter.close(); // Close the interpreter when it's no longer needed
//     super.dispose();
//   }
// }
