import 'package:entry/Login/services/firebase_auth_methods.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:entry/Login/screens/otp.dart';

class Register extends StatefulWidget {
  const Register({super.key});

  @override
  State<Register> createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  final TextEditingController phoneController = TextEditingController();

  @override
  void dispose() {
    super.dispose();
    phoneController.dispose();
  }

  void phoneSignIn() {
    String phoneNumber = phoneController.text.trim();
    if (phoneNumber.isNotEmpty) {
      // Trigger phone sign-in via Firebase
      FirebaseAuthMethods(FirebaseAuth.instance)
          .phoneSignIn(context, phoneNumber);
      setState(() {
        isClicked = !isClicked;
      });
      // After sign-in, navigate to the OTP page
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) =>
              const OtpPage(), // Assuming OtpPage is your OTP screen
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please enter a valid phone number")),
      );
    }
  }

  bool isClicked = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          const Center(
            child: Image(
              image: AssetImage('assets/images/login.png'),
              fit: BoxFit.cover,
              width: double.infinity,
              height: double.infinity,
            ),
          ),
          SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Image.asset(
                  'assets/images/register.png',
                  width: 250,
                  height: 180,
                ),
                const Text(
                  'Welcome to this app!',
                  style: TextStyle(
                    fontFamily: 'Cera Pro',
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
                const SizedBox(height: 50),
                Center(child: textField("Enter Name")),
                const SizedBox(height: 10),
                Center(child: phoneNumberField("Enter Phone Number")),
                const SizedBox(height: 10),
                Center(child: textField("Enter Password")),
                const SizedBox(height: 10),
                Center(child: textField("Confirm Password")),
                const SizedBox(height: 30),
                Container(
                  height: 60,
                  width: 250,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(50),
                    gradient: LinearGradient(
                      colors: isClicked
                          ? [
                              const Color.fromARGB(255, 152, 238, 179),
                              const Color.fromARGB(255, 22, 165, 139),
                            ]
                          : [
                              const Color.fromARGB(255, 22, 165, 139),
                              const Color.fromARGB(255, 152, 238, 179),
                            ],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.5),
                        spreadRadius: 2,
                        blurRadius: 5,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: GestureDetector(
                    onTap: phoneSignIn,
                    child: const Center(
                      child: Text(
                        "Register",
                        style: TextStyle(
                          fontFamily: 'Cera Pro',
                          fontSize: 25,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget textField(String hint) {
    return SizedBox(
      width: 350,
      child: Material(
        color: Colors.white,
        elevation: 7,
        borderRadius: BorderRadius.circular(30),
        child: Padding(
          padding: const EdgeInsets.symmetric(
            vertical: 10.0,
            horizontal: 30.0,
          ),
          child: TextFormField(
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: const TextStyle(
                color: Colors.black38,
                fontFamily: 'Cera Pro',
                fontWeight: FontWeight.bold,
              ),
              border: InputBorder.none,
            ),
          ),
        ),
      ),
    );
  }

  Widget phoneNumberField(String hint) {
    return SizedBox(
      width: 350,
      child: Material(
        color: Colors.white,
        elevation: 7,
        borderRadius: BorderRadius.circular(30),
        child: Padding(
          padding: const EdgeInsets.symmetric(
            vertical: 10.0,
            horizontal: 30.0,
          ),
          child: TextFormField(
            controller: phoneController,
            keyboardType: TextInputType.phone,
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: const TextStyle(
                color: Colors.black38,
                fontFamily: 'Cera Pro',
                fontWeight: FontWeight.bold,
              ),
              border: InputBorder.none,
            ),
          ),
        ),
      ),
    );
  }
}
