import 'dart:ui';
import 'package:entry/drought/models/weather_model.dart';
import 'package:entry/drought/services/services.dart';
import 'package:entry/util/pallete.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

class Drought extends StatefulWidget {
  const Drought({super.key});

  @override
  State<Drought> createState() => _MyWidgetState();
}

class _MyWidgetState extends State<Drought> {
  late WeatherData weatherInfo;
  myWeather() {
    WeatherServices().fetchWeather().then((value) {
      setState(() {
        weatherInfo = value;
      });
    });
  }

  @override
  void initState() {
    myWeather();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Pallete.floodbg,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon:
              const Icon(Icons.arrow_back, color: Color.fromARGB(255, 8, 0, 0)),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        centerTitle: true,
        title: Image.asset(
          'assets/images/flood_logo.png',
          height: 80,
          width: 50,
        ),
        systemOverlayStyle: const SystemUiOverlayStyle(
          statusBarBrightness: Brightness.light,
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(40, 1.2 * kToolbarHeight, 40, 20),
        child: Stack(
          children: [
            // Circle UI Elements
            Align(
              alignment: const AlignmentDirectional(9, -0.3),
              child: Container(
                height: 300,
                width: 300,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: Pallete.floodui1,
                ),
              ),
            ),
            Align(
              alignment: const AlignmentDirectional(-9, -0.3),
              child: Container(
                height: 300,
                width: 300,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: Pallete.floodui1,
                ),
              ),
            ),
            Align(
              alignment: const AlignmentDirectional(0, -1.2),
              child: Container(
                height: 300,
                width: 600,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: Pallete.floodui2,
                ),
              ),
            ),
            // Blur effect
            BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 100.0, sigmaY: 100.0),
              child: Container(
                decoration: const BoxDecoration(
                  color: Colors.transparent,
                ),
              ),
            ),
            // Main Content
            Center(
              child: Padding(
                padding:
                    const EdgeInsets.fromLTRB(40, 1.2 * kToolbarHeight, 40, 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    // WeatherDetails(weather: weatherInfo),
                    // _locationHeader(),
                    // const SizedBox(height: 10),
                    // _dateTimeInfo(),
                    const SizedBox(height: 50),
                    ElevatedButton(
                      child: const Text('MODIS Combined Flood'),
                      onPressed: () {
                        showModalBottomSheet(
                          context: context,
                          builder: (BuildContext context) {
                            return SizedBox(
                              height: 400,
                              child: Padding(
                                padding: const EdgeInsets.all(
                                    16.0), // Optional padding
                                child: Center(
                                  child: Container(
                                    height:
                                        300, // Set desired height for the map
                                    width: double
                                        .infinity, // Set width to fill the parent
                                    decoration: BoxDecoration(
                                      border: Border.all(
                                          color: Colors.blue,
                                          width:
                                              2), // Optional border for visibility
                                      borderRadius: BorderRadius.circular(
                                          12), // Optional rounded corners
                                    ),
                                    child: _buildMap(), // Your map widget
                                  ),
                                ),
                              ),
                            );
                          },
                        );
                      },
                    ),
                    ElevatedButton(
                      child: const Text('MODIS'),
                      onPressed: () {
                        showModalBottomSheet(
                          context: context,
                          builder: (BuildContext context) {
                            return const SizedBox(
                              height: 400,
                            );
                          },
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Map widget method
  Widget _buildMap() {
    return Expanded(
      child: FlutterMap(
        options: const MapOptions(
          initialCenter:
              LatLng(23.6850, 90.3563), // Set your desired center location
          minZoom: 8.0,
          maxZoom: 8.0, // Disable zooming, to focus on the image
        ),
        children: [
          // Your base map, e.g. OpenStreetMap
          TileLayer(
              urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png'),

          OverlayImage(
            bounds: LatLngBounds(
              const LatLng(22.0, 88.0), // Southwest corner of the image
              const LatLng(24.0, 92.0), // Northeast corner of the image
            ),
            imageProvider: const NetworkImage(
              "https://gitc.earthdata.nasa.gov/wmts/epsg3857/best/NDH_Drought_Hazard_Frequency_Distribution_1980-2000/default/Date/GoogleMapsCompatible_Level7/7/55/96.png",
            ),
            opacity: 0.8,
          ),
        ],
      ),
    );
  }
}

class WeatherDetails extends StatelessWidget {
  final WeatherData weather;
  const WeatherDetails({super.key, required this.weather});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          weather.name,
          style: const TextStyle(
              fontSize: 25,
              color: Pallete.subheading,
              fontWeight: FontWeight.bold),
        )
      ],
    );
  }
}
