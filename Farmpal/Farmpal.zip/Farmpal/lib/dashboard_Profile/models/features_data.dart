import 'package:entry/dashboard_Profile/models/features_model.dart';

List<Feature> features = [
  Feature(
    id: 0,
    name: 'AgriSmart Advisor',
    imagePath: 'assets/images/dash_agri.png',
  ),
  Feature(
    id: 1,
    name: 'Flood',
    imagePath: 'assets/images/dash_flood.png',
  ),
  Feature(
    id: 2,
    name: 'Drought',
    imagePath: 'assets/images/dash_drought.png',
  ),
  Feature(
    id: 3,
    name: 'Irrigation',
    imagePath: 'assets/images/dash_irrigation.png',
  ),
  Feature(
    id: 4,
    name: 'Diseases Detection',
    imagePath: 'assets/images/dash_disease.png',
  ),
  Feature(
    id: 5,
    name: 'Community',
    imagePath: 'assets/images/dash_community.png',
  ),
  Feature(
    id: 6,
    name: 'Xorina',
    imagePath: 'assets/images/dash_xorina.png',
  ),
];
List<image_video> iv = [
  image_video(
    id: 0,
    name: 'Succuient',
    imagePath: 'assets/images/01.png',
  ),
  image_video(
    id: 1,
    name: 'Succuient',
    imagePath: 'assets/images/02.png',
  ),
  image_video(
    id: 2,
    name: 'Ficus retusa',
    imagePath: 'assets/images/03.png',
  ),
];

class NASAImage {
  final String title;
  final String nasaId;
  final String description;
  final String href;

  NASAImage(
      {required this.title,
      required this.nasaId,
      required this.description,
      required this.href});

  factory NASAImage.fromJson(Map<String, dynamic> json) {
    return NASAImage(
      title: json['data'][0]['title'] ?? '',
      nasaId: json['data'][0]['nasa_id'] ?? '',
      description: json['data'][0]['description'] ?? '',
      href: json['links'][0]['href'] ?? '',
    );
  }
}
