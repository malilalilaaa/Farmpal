import 'package:flutter/material.dart';
import 'package:entry/Xorina/openai_sevice.dart';
import 'package:entry/Xorina/feature_box.dart';
import 'package:entry/Xorina/pallete.dart';
import 'package:speech_to_text/speech_recognition_result.dart';
import 'package:speech_to_text/speech_to_text.dart';

class XorinaMainPg extends StatefulWidget {
  const XorinaMainPg({super.key});

  @override
  State<XorinaMainPg> createState() => _HomePageState();
}

class _HomePageState extends State<XorinaMainPg> {
  final speechToText = SpeechToText();
  String lastWords = '';
  final OpenAIService openAIService = OpenAIService();
  String? generateContant;
  String? generateImageUrl;

  @override
  void initState() {
    super.initState();
    initSpeechToText();
  }

  Future<void> initSpeechToText() async {
    await speechToText.initialize();
    setState(() {});
  }

  Future<void> startListening() async {
    await speechToText.listen(onResult: onSpeechResult);
    setState(() {});
  }

  Future<void> stopListening() async {
    await speechToText.stop();
    setState(() {});
  }

  void onSpeechResult(SpeechRecognitionResult result) {
    setState(() {
      lastWords = result.recognizedWords;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Xorina',
          style: TextStyle(
              fontWeight: FontWeight.bold,
              fontFamily: 'Cera Pro',
              color: Pallete.mainFontColor),
        ),
        leading: const Icon(Icons.arrow_back_ios_new_outlined),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/images/xorina_bg.png'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          SingleChildScrollView(
            child: Column(
              children: [
                Stack(
                  children: [
                    Center(
                      child: Container(
                        height: 120,
                        width: 120,
                        margin: const EdgeInsets.only(top: 4),
                        decoration: const BoxDecoration(
                            color: Pallete.assistantCircleColor,
                            shape: BoxShape.circle),
                      ),
                    ),
                    Container(
                      height: 120,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        image: DecorationImage(
                          image: AssetImage('assets/images/xorina.png'),
                        ),
                      ),
                    ),
                  ],
                ),
                Visibility(
                  visible: generateImageUrl == null,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 30, vertical: 20),
                    margin: const EdgeInsets.symmetric(horizontal: 30)
                        .copyWith(top: 20),
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: Pallete.borderColor,
                      ),
                      borderRadius: BorderRadius.circular(20).copyWith(
                        topLeft: Radius.zero,
                      ),
                      color: Colors.white.withOpacity(0.8),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 5.0),
                      child: Text(
                        generateContant == null
                            ? 'Hello! How can I help you? Feel free to ask me anything...'
                            : generateContant!,
                        style: TextStyle(
                          color: Pallete.mainFontColor,
                          fontFamily: 'Cera Pro',
                          fontSize: generateContant == null ? 25 : 18,
                        ),
                      ),
                    ),
                  ),
                ),
                if (generateImageUrl != null)
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: Image.network(generateImageUrl!),
                    ),
                  ),
                Visibility(
                  visible: generateContant == null && generateImageUrl == null,
                  child: Container(
                    padding: const EdgeInsets.all(10),
                    alignment: Alignment.centerLeft,
                    margin: const EdgeInsets.only(top: 10, left: 25),
                    child: const Text(
                      'Here are a few features',
                      style: TextStyle(
                          fontFamily: 'Cera Pro',
                          color: Pallete.mainFontColor,
                          fontSize: 18,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                const Column(
                  children: [
                    FeatureBox(
                      headerText: 'ChatGPT',
                      desciptionText:
                          'A smarter way to get organized and informed with ChatGPT',
                      color: Pallete.chatdallcolor,
                    ),
                    FeatureBox(
                      headerText: 'Dall-E',
                      desciptionText:
                          'Get inspired and stay creative with your personal assistant powered by Dall-E',
                      color: Pallete.chatdallcolor,
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Pallete.firstSuggestionBoxColor,
        onPressed: () async {
          if (await speechToText.hasPermission && speechToText.isNotListening) {
            await startListening();
          } else if (speechToText.isListening) {
            final speech = await openAIService.isArtPromptAPI(lastWords);
            if (speech.contains('https')) {
              generateImageUrl = speech;
              generateContant = null;
              setState(() {});
            } else {
              generateImageUrl = null;
              generateContant = speech;
              setState(() {});
              print(speech);
            }
            await stopListening();
          } else {
            initSpeechToText();
          }
        },
        child: const Icon(Icons.mic),
      ),
    );
  }
}
