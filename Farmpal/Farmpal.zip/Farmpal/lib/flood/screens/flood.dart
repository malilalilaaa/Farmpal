import 'dart:ui';
import 'package:entry/drought/models/weather_model.dart';
import 'package:entry/drought/services/services.dart';
import 'package:entry/util/pallete.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

class Flood extends StatefulWidget {
  const Flood({super.key});

  @override
  State<Flood> createState() => _MyWidgetState();
}

class _MyWidgetState extends State<Flood> {
  WeatherData? weatherInfo;
  myWeather() {
    WeatherServices().fetchWeather().then((value) {
      setState(() {
        weatherInfo = value;
      });
    });
  }

  @override
  void initState() {
    myWeather();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Pallete.floodbg,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon:
              const Icon(Icons.arrow_back, color: Color.fromARGB(255, 8, 0, 0)),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        centerTitle: true,
        title: Image.asset(
          'assets/images/flood_logo.png',
          height: 80,
          width: 50,
        ),
        systemOverlayStyle: const SystemUiOverlayStyle(
          statusBarBrightness: Brightness.light,
        ),
      ),
      body: weatherInfo == null
          ? const Center(
              child: CircularProgressIndicator()) // Loading indicator
          : Padding(
              padding:
                  const EdgeInsets.fromLTRB(40, 1.2 * kToolbarHeight, 40, 20),
              child: Stack(
                children: [
                  // Circle UI Elements
                  Align(
                    alignment: const AlignmentDirectional(9, -0.3),
                    child: Container(
                      height: 300,
                      width: 300,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Pallete.floodui1,
                      ),
                    ),
                  ),
                  Align(
                    alignment: const AlignmentDirectional(-9, -0.3),
                    child: Container(
                      height: 300,
                      width: 300,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Pallete.floodui1,
                      ),
                    ),
                  ),
                  Align(
                    alignment: const AlignmentDirectional(0, -1.2),
                    child: Container(
                      height: 300,
                      width: 600,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Pallete.floodui2,
                      ),
                    ),
                  ),
                  // Blur effect
                  BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 100.0, sigmaY: 100.0),
                    child: Container(
                      decoration: const BoxDecoration(
                        color: Colors.transparent,
                      ),
                    ),
                  ),
                  // Main Content
                  Center(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(
                          40, 1.2 * kToolbarHeight, 40, 20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          // Location and Date in the middle
                          _locationHeader(),
                          const SizedBox(height: 10),
                          _dateTimeInfo(),

                          // Four Containers (Temperature, Humidity, pH, Rainfall)
                          const SizedBox(height: 30),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              _infoContainer('Temperature',
                                  '${weatherInfo!.temperature}°C'),
                              _infoContainer(
                                  'Humidity', '${weatherInfo!.humidity} mm'),
                            ],
                          ),
                          const SizedBox(height: 20),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              _infoContainer(
                                  'pH Level', '${weatherInfo!.phLevel}'),
                              _infoContainer('Rainfall',
                                  '${weatherInfo!.rainfallAmount} mm'),
                            ],
                          ),

                          const SizedBox(height: 50),
                          // Buttons
                          ElevatedButton(
                            child: const Text('MODIS Combined Flood'),
                            onPressed: () {
                              showModalBottomSheet(
                                context: context,
                                builder: (BuildContext context) {
                                  return SizedBox(
                                    height: 400,
                                    child: Padding(
                                      padding: const EdgeInsets.all(16.0),
                                      child: Center(
                                        child: Container(
                                          height: 300,
                                          width: double.infinity,
                                          decoration: BoxDecoration(
                                            border: Border.all(
                                                color: Colors.blue, width: 2),
                                            borderRadius:
                                                BorderRadius.circular(12),
                                          ),
                                          child: _buildMap(),
                                        ),
                                      ),
                                    ),
                                  );
                                },
                              );
                            },
                          ),
                          ElevatedButton(
                            child: const Text('MODIS'),
                            onPressed: () {
                              showModalBottomSheet(
                                context: context,
                                builder: (BuildContext context) {
                                  return const SizedBox(
                                    height: 400,
                                  );
                                },
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  // Helper methods for containers
  Widget _infoContainer(String title, String data) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Pallete.floodui2,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.blueGrey, width: 2),
      ),
      child: Column(
        children: [
          Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            data,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 16,
            ),
          ),
        ],
      ),
    );
  }

  // Map widget method
  Widget _buildMap() {
    return Expanded(
      child: FlutterMap(
        options: const MapOptions(
          initialCenter: LatLng(23.6850, 90.3563),
          minZoom: 8.0,
          maxZoom: 8.0,
        ),
        children: [
          TileLayer(
              urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png'),
          OverlayImage(
            bounds: LatLngBounds(
              const LatLng(22.0, 88.0),
              const LatLng(24.0, 92.0),
            ),
            imageProvider: const NetworkImage(
              "https://gitc.earthdata.nasa.gov/wmts/epsg3857/best/MODIS_Combined_Flood_2-Day/default/2024-09-21/GoogleMapsCompatible_Level9/9/222/384.png",
            ),
            opacity: 0.8,
          ),
        ],
      ),
    );
  }

  Widget _locationHeader() {
    return Text(
      weatherInfo!.name,
      style: const TextStyle(
          fontSize: 25, color: Pallete.subheading, fontWeight: FontWeight.bold),
    );
  }

  Widget _dateTimeInfo() {
    return Text(
      'Date: ${DateTime.now().toString().split(" ")[0]}',
      style: const TextStyle(
          fontSize: 18, color: Pallete.subheading, fontWeight: FontWeight.w600),
    );
  }
}
