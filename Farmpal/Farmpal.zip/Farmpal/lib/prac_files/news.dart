import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class NASAImage {
  final String title;
  final String nasaId;
  final String description;
  final String href;

  NASAImage(
      {required this.title,
      required this.nasaId,
      required this.description,
      required this.href});

  factory NASAImage.fromJson(Map<String, dynamic> json) {
    return NASAImage(
      title: json['data'][0]['title'] ?? '',
      nasaId: json['data'][0]['nasa_id'] ?? '',
      description: json['data'][0]['description'] ?? '',
      href: json['links'][0]['href'] ?? '',
    );
  }
}

class VideoCard extends StatelessWidget {
  final NASAImage nasaImage;
  final VoidCallback onTap;

  VideoCard({required this.nasaImage, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Card(
        elevation: 4,
        margin: EdgeInsets.symmetric(horizontal: 8),
        child: Column(
          children: [
            Image.network(nasaImage.href,
                fit: BoxFit.cover, height: 150, width: double.infinity),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                nasaImage.title,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8.0),
              child: Text(
                nasaImage.description,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class VideoSearchScreen extends StatefulWidget {
  @override
  _VideoSearchScreenState createState() => _VideoSearchScreenState();
}

class _VideoSearchScreenState extends State<VideoSearchScreen> {
  final TextEditingController _searchController = TextEditingController();
  List<NASAImage> _searchResults = [];

  Future<void> searchVideos(String query) async {
    final response = await http.get(Uri.parse(
        'https://images-api.nasa.gov/search?q=$query&media_type=video'));

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      final List<NASAImage> images = (data['collection']['items'] as List)
          .map((item) => NASAImage.fromJson(item))
          .toList();

      setState(() {
        _searchResults = images; // Store parsed results in the state
      });
    } else {
      // Handle error
      print('Failed to load search results');
    }
  }

  Future<void> fetchVideoAsset(String nasaId) async {
    final response =
        await http.get(Uri.parse('https://images-api.nasa.gov/asset/$nasaId'));

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      // Use the video URL to display or play it in your app
      final videoUrl = data['collection']['items'][0]['href']; // Example path
      print('Video URL: $videoUrl');
      // Implement your video player here
    } else {
      // Handle error
      print('Failed to load video asset');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('NASA Video Search'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _searchController,
              decoration: InputDecoration(
                labelText: 'Search for videos',
                suffixIcon: IconButton(
                  icon: Icon(Icons.search),
                  onPressed: () {
                    searchVideos(_searchController.text);
                  },
                ),
              ),
            ),
            Expanded(
              child: PageView.builder(
                itemCount: _searchResults.length,
                itemBuilder: (context, index) {
                  final nasaImage = _searchResults[index];

                  return VideoCard(
                    nasaImage: nasaImage,
                    onTap: () {
                      fetchVideoAsset(nasaImage.nasaId);
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
