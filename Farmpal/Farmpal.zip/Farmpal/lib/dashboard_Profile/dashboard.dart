import 'package:flutter/material.dart';
import 'package:entry/dashboard_Profile/features.dart';
import 'package:entry/dashboard_Profile/drawer_screen.dart';

class Dashboard extends StatelessWidget {
  const Dashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: Stack(
          children: [
            DrawerScreen(),
            Features(),
          ],
        ),
      ),
    );
  }
}
