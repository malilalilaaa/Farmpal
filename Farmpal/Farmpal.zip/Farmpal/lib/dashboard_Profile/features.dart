//ignore_for_file: avoid_print

// ignore_for_file: prefer_const_constructors

import 'dart:convert';
import 'package:entry/Xorina/xorina_home.dart';
import 'package:entry/crop_recommand/filter.dart';

import 'package:entry/dashboard_Profile/models/features_data.dart';
import 'package:entry/disease/image.dart';
import 'package:entry/drought/drought.dart';
import 'package:entry/flood/screens/flood.dart';
import 'package:entry/util/pallete.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

class NASAImage {
  final String title;
  final String nasaId;
  final String description;
  final String href;

  NASAImage({
    required this.title,
    required this.nasaId,
    required this.description,
    required this.href,
  });

  factory NASAImage.fromJson(Map<String, dynamic> json) {
    return NASAImage(
      title: json['data'][0]['title'] ?? '',
      nasaId: json['data'][0]['nasa_id'] ?? '',
      description: json['data'][0]['description'] ?? '',
      href: json['links'][0]['href'] ?? '',
    );
  }
}

class Features extends StatefulWidget {
  const Features({super.key});

  @override
  State<Features> createState() => _FeaturesState();
}

class _FeaturesState extends State<Features> {
  PageController controller = PageController();

  int activePage = 0;
  final List<Color> cardColors = [
    Pallete.disease,
    Pallete.irrigation,
    Pallete.disease,
    Pallete.irrigation,
    Pallete.disease,
    Pallete.irrigation,
    Pallete.disease,
  ];
  final List<Color> borderColors = [
    Pallete.agriadviser,
    Pallete.flood,
    Pallete.drought,
    Pallete.irrigation,
    Pallete.disease,
    Pallete.xorina,
    Pallete.community,
  ];
  final TextEditingController _searchController = TextEditingController();
  List<NASAImage> _searchResults = [];

  Future<void> searchVideos(String query) async {
    final response = await http.get(Uri.parse(
        'https://images-api.nasa.gov/search?q=$query&media_type=video'));

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      final List<NASAImage> images = (data['collection']['items'] as List)
          .map((item) => NASAImage.fromJson(item))
          .toList();

      setState(() {
        _searchResults = images;
      });
    } else {
      print('Failed to load search results');
    }
  }

  Future<void> fetchVideoAsset(String nasaId) async {
    final response =
        await http.get(Uri.parse('https://images-api.nasa.gov/asset/$nasaId'));

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      final videoUrl = data['collection']['items'][0]['href'];
      print('Video URL: $videoUrl');

      if (await canLaunchUrl(videoUrl)) {
        await launchUrl(videoUrl);
      } else {
        print('Could not launch $videoUrl');
      }
    } else {
      print('Failed to load video asset');
    }
  }

  double xoffset = 0;
  double yoffset = 0;
  bool isDrawerOpen = false;

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      padding: const EdgeInsets.fromLTRB(20, 1.2 * kToolbarHeight, 0, 15),
      transform: Matrix4.translationValues(xoffset, yoffset, 0)
        ..scale(isDrawerOpen ? 0.85 : 1.00)
        ..rotateZ(isDrawerOpen ? -50 : 0),
      duration: const Duration(milliseconds: 200),
      decoration: BoxDecoration(
          color: Pallete.community,
          borderRadius: isDrawerOpen
              ? BorderRadius.circular(40)
              : BorderRadius.circular(0)),
      child: SingleChildScrollView(
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                isDrawerOpen
                    ? GestureDetector(
                        child: const Icon(Icons.arrow_back_ios),
                        onTap: () {
                          setState(() {
                            xoffset = 0;
                            yoffset = 0;
                            isDrawerOpen = false;
                          });
                        },
                      )
                    : GestureDetector(
                        child: const Icon(Icons.menu),
                        onTap: () {
                          setState(() {
                            xoffset = 290;
                            yoffset = 80;
                            isDrawerOpen = true;
                          });
                        },
                      ),
              ],
            ),
            SingleChildScrollView(
              child: Column(
                children: [
                  const SizedBox(
                    height: 20,
                  ),
                  const Center(
                    child: Column(
                      mainAxisSize: MainAxisSize
                          .min, // Minimize the column's size vertically
                      children: [
                        Text(
                          'FarmPal!',
                          style: TextStyle(
                              fontSize: 22,
                              fontFamily: 'Cera Pro',
                              letterSpacing: 1.0,
                              color: Pallete.heading,
                              fontWeight: FontWeight.w900),
                        ),
                        Text(
                          'Farm Smart, Grow Strong',
                          style: TextStyle(
                              fontSize: 22,
                              fontFamily: 'Cera Pro',
                              letterSpacing: 1.0,
                              color: Pallete.subheading,
                              fontWeight: FontWeight.w500),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'Explore',
                        style: TextStyle(
                          fontFamily: 'Cera Pro',
                          color: Pallete.heading,
                          fontWeight: FontWeight.bold,
                          fontSize: 30.0,
                          shadows: [
                            Shadow(
                              blurRadius: 5.0,
                              color: Colors.black45,
                              offset: Offset(2.0, 2.0),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 300.0,
                    width: 450.0,
                    child: PageView.builder(
                      itemCount: cardColors.length,
                      controller: controller,
                      physics: const BouncingScrollPhysics(),
                      padEnds: false,
                      pageSnapping: true,
                      onPageChanged: (value) =>
                          setState(() => activePage = value),
                      itemBuilder: (BuildContext context, int index) {
                        bool active = index == activePage;
                        return slider_features(active, index);
                      },
                    ),
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'Nasa Gallery',
                        style: TextStyle(
                          fontFamily: 'Cera Pro',
                          color: Pallete.heading,
                          fontWeight: FontWeight.bold,
                          fontSize: 30.0,
                          shadows: [
                            Shadow(
                              blurRadius: 5.0,
                              color: Colors.black45,
                              offset: Offset(2.0, 2.0),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  SingleChildScrollView(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      children: [
                        TextField(
                          controller: _searchController,
                          decoration: InputDecoration(
                            labelText: 'Search for videos',
                            suffixIcon: IconButton(
                              icon: const Icon(Icons.search),
                              onPressed: () {
                                searchVideos(_searchController.text);
                              },
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 300.0,
                    width: 450.0,
                    child: PageView.builder(
                      itemCount: _searchResults.length,
                      controller: controller,
                      physics: const BouncingScrollPhysics(),
                      padEnds: false,
                      pageSnapping: true,
                      onPageChanged: (value) =>
                          setState(() => activePage = value),
                      itemBuilder: (BuildContext context, int index) {
                        bool active = index == activePage;
                        return slider_gallery(active, _searchResults[index]);
                      },
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ignore: non_constant_identifier_names
  AnimatedContainer slider_gallery(bool active, NASAImage nasaImage) {
    double margin = active ? 20 : 30;
    return AnimatedContainer(
      duration: const Duration(
        microseconds: 500,
      ),
      curve: Curves.easeInCubic,
      margin: EdgeInsets.all(margin),
      child: gallery(nasaImage),
    );
  }

  // ignore: non_constant_identifier_names
  AnimatedContainer slider_features(active, index) {
    double margin = active ? 20 : 30;
    return AnimatedContainer(
      duration: const Duration(
        microseconds: 500,
      ),
      curve: Curves.easeInCubic,
      margin: EdgeInsets.all(margin),
      child: dashboardCard(index),
    );
  }

  Widget dashboardCard(int index) {
    return GestureDetector(
      onTap: () {
        if (index == 0) {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => CropRecommendationApp()),
          );
        } else if (index == 1) {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const Flood()),
          );
        } else if (index == 2) {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const Drought()),
          );
        } else if (index == 4) {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const DISEASE_IMAGE()),
          );
        } else if (index == 6) {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const XorinaHome()),
          );
        }
      },
      child: Container(
        padding: const EdgeInsets.all(8.0),
        decoration: BoxDecoration(
          color: cardColors[index],
          boxShadow: [
            BoxShadow(
              color: borderColors[index].withOpacity(0.05),
              blurRadius: 15,
              offset: const Offset(5, 5),
            ),
          ],
          border: Border.all(
            color: const Color.fromARGB(255, 153, 194, 154),
            width: 2,
          ),
          borderRadius: BorderRadius.circular(30.0),
        ),
        child: Stack(
          // Use Stack to overlay text on the image
          children: [
            // Background image
            Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage(features[index].imagePath),
                  fit: BoxFit.cover,
                ),
                borderRadius: BorderRadius.circular(30.0),
              ),
            ),
            // Text overlay
            Align(
              alignment: Alignment.bottomCenter,
              child: Padding(
                padding: const EdgeInsets.only(bottom: 7),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget gallery(NASAImage nasaImage) {
    return GestureDetector(
      onTap: () {
        fetchVideoAsset(nasaImage.nasaId);
      },
      child: Container(
        padding: const EdgeInsets.all(8.0),
        decoration: BoxDecoration(
          color:
              Pallete.disease, // Use a default color or a better color choice
          borderRadius: BorderRadius.circular(30.0),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 15,
              offset: const Offset(5, 5),
            ),
          ],
        ),
        child: Column(
          children: [
            Image.network(
              nasaImage.href,
              fit: BoxFit.cover,
              height: 150,
              width: double.infinity,
              errorBuilder: (context, error, stackTrace) =>
                  const Icon(Icons.error),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 8.0),
              child: Text(
                nasaImage.title,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16.0,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
