const openAIAPIKey =
    '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';
