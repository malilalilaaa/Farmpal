import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';

class RecommendedCrop extends StatefulWidget {
  const RecommendedCrop({super.key});

  @override
  State<RecommendedCrop> createState() => _RecommendedCropState();
}

class _RecommendedCropState extends State<RecommendedCrop> {
  final List<String> urlImage = [
    'https://images.unsplash.com/photo-1709607389103-561ec87485e5?q=80&w=1887&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    'https://images.unsplash.com/photo-1415381850596-1d29bce989f8?q=80&w=1780&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    'https://plus.unsplash.com/premium_photo-1725619406627-198049ca7162?q=80&w=1886&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
  ];

  // List to hold cart items
  List<String> cartItems = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.black),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          // Background Image
          const Center(
            child: Image(
              image: AssetImage('assets/images/login.png'),
              fit: BoxFit.cover,
              width: double.infinity,
              height: double.infinity,
            ),
          ),

          // Main Content
          Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 40),
              // Logo/Image
              Image.asset(
                'assets/images/cr.png',
                width: 181,
                height: 120,
              ),
              const Text(
                'Crop Recommendation',
                style: TextStyle(
                  fontFamily: 'Cera Pro',
                  fontSize: 25,
                  fontWeight: FontWeight.bold,
                  color: Color.fromARGB(255, 34, 205, 85),
                ),
              ),
              const SizedBox(height: 50),

              // CarouselSlider for Images
              CarouselSlider.builder(
                itemCount: urlImage.length,
                itemBuilder: (context, index, realIndex) {
                  final urlImages = urlImage[index];
                  return Stack(
                    alignment: Alignment.bottomRight,
                    children: [
                      buildImage(urlImages, index),
                      // Add button (Plus Sign) in the bottom right corner
                      Positioned(
                        bottom: 10,
                        right: 10,
                        child: FloatingActionButton(
                          onPressed: () {
                            setState(() {
                              cartItems.add('Item $index');
                            });
                          },
                          mini: true,
                          backgroundColor: Colors.green,
                          child: const Icon(Icons.add),
                        ),
                      ),
                    ],
                  );
                },
                options: CarouselOptions(height: 400),
              ),

              const Spacer(),

              // Cart Section at the bottom
              Container(
                padding:
                    const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                color: Colors.white,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'Cart',
                      style: TextStyle(
                        fontFamily: 'Cera Pro',
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 34, 205, 85),
                      ),
                    ),
                    // Cart Item Count
                    Stack(
                      children: [
                        IconButton(
                          icon: const Icon(
                            Icons.arrow_circle_right_sharp,
                            size: 30,
                          ),
                          onPressed: () {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('Added to profile successfully'),
                                duration: Duration(seconds: 2),
                              ),
                            );
                          },
                        ),
                        if (cartItems.isNotEmpty)
                          Positioned(
                            right: 0,
                            child: Container(
                              padding: const EdgeInsets.all(2),
                              decoration: BoxDecoration(
                                color: Colors.red,
                                borderRadius: BorderRadius.circular(10),
                              ),
                              constraints: const BoxConstraints(
                                minWidth: 16,
                                minHeight: 16,
                              ),
                              child: Text(
                                '${cartItems.length}',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget buildImage(String urlImage, int index) => Container(
        margin: const EdgeInsets.symmetric(horizontal: 5),
        child: Image.network(
          urlImage,
          fit: BoxFit.cover,
          frameBuilder: (BuildContext context, Widget child, int? frame,
              bool wasSynchronouslyLoaded) {
            if (wasSynchronouslyLoaded) {
              return child;
            }
            return AnimatedScale(
              scale: frame == null ? 0.8 : 1.0,
              duration: const Duration(seconds: 1),
              child: child,
            );
          },
        ),
      );
}
