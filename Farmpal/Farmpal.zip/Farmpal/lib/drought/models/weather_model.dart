class WeatherData {
  final String name;
  final double temperature; // Use 'temperature' instead of 'temp'
  final double humidity;
  final double phLevel; // Use 'phLevel' instead of 'ph'
  final double rainfallAmount; // Use 'rainfallAmount' instead of 'rainfall'

  WeatherData({
    required this.name,
    required this.temperature,
    required this.humidity,
    required this.phLevel,
    required this.rainfallAmount,
  });

  factory WeatherData.fromJson(Map<String, dynamic> json) {
    return WeatherData(
      name: json['name'],
      temperature: json['temp'], // Make sure the keys match your API response
      humidity: json['humidity'],
      phLevel: json['ph'],
      rainfallAmount: json['rainfall'],
    );
  }
}

class WeatherInfo {
  final String main;

  WeatherInfo({
    required this.main,
  });

  factory WeatherInfo.fromJson(Map<String, dynamic> json) {
    return WeatherInfo(
      main: json['main'],
    );
  }
}

class Temperature {
  final double current;

  Temperature({required this.current});

  factory Temperature.fromJson(dynamic json) {
    return Temperature(
      current: (json - 273.15), // Kelvin to Celsius
    );
  }
}
